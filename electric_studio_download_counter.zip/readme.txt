=== Plugin Name ===
Contributors: irvingswiftj, Matthew Burrows
Tags: comments, spam
Requires at least: 3.1
Tested up to: 3.1.4
Stable tag: 0.5

Get Statistics about your downloads.

== Description ==

View how many people have downloaded what files from your site.

Features include:
* Allows you to specify which file types to track.
* View top ten downloads
* View this month's downloads
* View this week's downloads

== Installation ==

Install from wordpress plugins directory.

Else, to install manually:

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 1.0 =
* Stable Release

= 0.5 =
* Beta version release.

== Upgrade Notice ==

= 1.0 =
Stable release.

= 0.5 =
This is the beta version.


